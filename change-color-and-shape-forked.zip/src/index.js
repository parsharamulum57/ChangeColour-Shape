import "./styles.css";

let arr = ["red", "yellow", "green"];
function changeCol() {
  var col = document.getElementById("app");
  var ele = Math.floor(Math.random() * arr.length);
  //console.log(arr[ele]);
  col.style.backgroundColor = `${arr[ele]}`;
}

var b = ["circle", "triangle", "square"];
function changeShape() {
  var ob = document.getElementById("sh");
  // ob.classList.forEach(e->)
  //console.log(ob.classList[0]);
  var f = ob.classList[0];
  ob.classList.remove(f);
  var c = Math.floor(Math.random() * b.length);
  ob.classList.add(b[c]);
}

var col_but = document.getElementById("col");
//console.log(col_but);
var shape_but = document.getElementById("shape");

col_but.addEventListener("click", changeCol);
shape_but.addEventListener("click", changeShape);
